# Caregiver Inbox — Workflow

How the six skills in `caregiver-inbox-skill/` actually run, in order, with what data passes between them and where the process pauses for the caregiver.

## Pipeline

```text
                 ┌────────────────────┐
  first run or   │  care-onboarding   │   creates care-data/ if missing,
  reconnect ───▶ │  (runs once)       │   writes care-data/care-connections.json,
                 └─────────┬──────────┘   seeds an empty care-data/care-state.json
                           │              (wacli / gog / mock-portal status)
                           ▼
                 ┌────────────────────┐
  "check Mum's   │  caregiver-inbox   │   reads care-data/care-connections.json
  updates" ─────▶│  (orchestrator)    │   stop here if a needed source is
                 └─────────┬──────────┘   not_connected — routes back to
                           │              care-onboarding instead of guessing.
                           │              Also live-reprobes the portal every
                           │              run (a cached "connected" status
                           │              isn't proof it's up right now) and
                           │              auto-starts it if it's down.
                           ▼
                 ┌────────────────────┐
                 │  care-source-sync  │   reads: care-data/care-state.json (since=,
                 │                    │          or "everything" if absent/fresh)
                 │                    │   calls: mock-health-portal API,
                 │                    │          wacli (scoped demo chat),
                 │                    │          gog calendar search/conflicts
                 │                    │   writes: care-data/incoming-updates.json,
                 │                    │           care-data/care-state.json
                 │                    │           (lastConfirmedCheck only)
                 └─────────┬──────────┘
                           │
                           ▼
                 ┌────────────────────┐
                 │  care-state-diff   │   reads: care-data/incoming-updates.json,
                 │                    │          care-data/care-state.json
                 │                    │   writes: care-data/findings.json
                 └─────────┬──────────┘   (classified + conflict-flagged)
                           │
                           ▼
                 ┌────────────────────┐
                 │  care-briefing     │   reads: care-data/findings.json
                 │                    │   writes: care-data/caregiver-briefing-<date>.md
                 └─────────┬──────────┘
                           │
              ┌────────────┴────────────┐
              │   shown to the caregiver  │
              └────────────┬────────────┘
                           ▼
                 ┌────────────────────┐
                 │ care-action-       │   calendar item, sources agree AND
                 │ executor           │   no busy-time conflict?
                 │                    │     yes → auto-write via gog, no pause
                 │                    │     no  → hold for explicit approval
                 │                    │   everything else → always wait for
                 │                    │     explicit approval, then act via
                 │                    │     gog / wacli send / care-state.json
                 │                    │   writes: care-data/care-state.json (updated),
                 │                    │           care-data/care-action-audit.jsonl
                 └─────────┬──────────┘
                           │
                           ▼
                  report: what auto-updated, what was approved
                  and executed, what's still unresolved and who
                  owns it
```

`care-data/` lives at a fixed location — `~/Desktop/care-data/` (`%USERPROFILE%\Desktop\care-data` on Windows) — no search needed. `mock-health-portal/` is different: it's a real project folder whose location genuinely varies per machine and per user, so it's located via a bounded search (current directory, then common project locations, then ask the user — never an unbounded filesystem scan) documented in `caregiver-inbox-skill/shared/references/care-connections-schema.md`.

## Stage-by-stage

### 1. `care-onboarding.md` — runs once

Triggered the first time `care-data/care-connections.json` doesn't exist, or when the user explicitly asks to (re)connect a source.

- If wacli or gog isn't installed at all, directs the user to the WorkBuddy Skills marketplace before continuing — checked via each tool's own status command (`wacli doctor`, `gog auth list`), not a shell `command -v`, since that distinguishes "not installed" from "installed but not authenticated," which a PATH check can't.
- Links WhatsApp via `wacli auth`, then explicitly asks the user which group chat or phone number(s) it's allowed to read from — never defaults to "all chats," never picks for them, never widens scope later without asking again.
- Links Google Calendar via `gog auth credentials` / `gog auth add --services calendar`, checked via `gog auth list`.
- Confirms the mock-health-portal API is reachable via a direct HTTP call (`sourceId: "care-portal"`, `tool: "direct_http"`) — locates the portal via the bounded search procedure rather than assuming a path, and starts the backend itself if it's not running.
- Creates `care-data/` at its fixed location (`~/Desktop/care-data/`) if it doesn't exist yet, and seeds an empty `care-data/care-state.json` (schema shape, no `lastConfirmedCheck`) if one isn't already there — never seeded from the demo fixture, since that fixture's persona doesn't match whatever patient the connected portal actually returns.
- Output: `care-data/care-connections.json` — the only file that says what's actually connected and how narrowly it's scoped.

### 2. `caregiver-inbox.md` — orchestrator, entry point

Every normal request ("check Mum's updates," "prepare today's briefing") starts here.

- Reads `care-data/care-connections.json` first. If a needed source is `not_connected`, it automatically hands off to `care-onboarding` scoped to just that source, rather than telling the user to run a separate command — it never runs a partial pipeline against an unverified source. The hand-off itself is automatic; the actual account-linking steps inside onboarding (QR scan, OAuth consent) still require the user's in-the-moment confirmation.
- Re-probes the mock portal live every run regardless of cached status (it's a local process that can die between sessions) and auto-starts it if needed before trusting it.
- Decides scope: full pipeline, or a partial run (e.g. "just show me the briefing we already have" skips sync).
- Invokes the next four skills in order, passing each one's output file forward untouched.

### 3. `care-source-sync.md` — retrieval

- Reads `lastConfirmedCheck` from `care-data/care-state.json` to pull only what's new.
- Calls the mock-health-portal connector operations (`get_recent_updates`, `get_appointments`, etc.) and reads exactly the chat or number(s) the user specified during onboarding via `wacli` (exact search syntax confirmed via `wacli messages --help` at run time, not assumed).
- For each appointment from the portal, also checks Google Calendar via `gog calendar search` (does an event already exist, and does it match?) and `gog calendar conflicts` (does the proposed time double-book against another commitment?) — the one case where this skill reads from a source it also writes to elsewhere, used only for comparison.
- Filters out anything not care-relevant, tags every kept item with source/timestamp/evidence.
- Output: `care-data/incoming-updates.json` — raw, source-tagged, not yet classified.

### 4. `care-state-diff.md` — comparison

- Classifies each item: new / changed / completed / unresolved question / possible contradiction / duplicate / informational.
- Where two sources disagree (e.g. portal says 15 Aug, WhatsApp message still says 12 Aug), flags it as a possible contradiction and keeps both values with their sources — never picks one silently. Google Calendar counts as a ranked source here too (rank 4) when it has its own existing entry.
- Separately flags busy-time conflicts (from `gog calendar conflicts`) — not a source disagreement, but a scheduling clash that also blocks calendar auto-write.
- Detects downstream effects: calendar, tasks, family assignments, equipment.
- Output: `care-data/findings.json`.

### 5. `care-briefing.md` — summary

- Renders `care-data/findings.json` into the standard sections: Needs attention now / Completed / Waiting for others / Possible conflicts / Informational updates.
- Output: `care-data/caregiver-briefing-<date>.md`, shown to the caregiver. Nothing executes until this has been seen.

### 6. `care-action-executor.md` — approval and execution

- **Calendar exception**: if `care-state-diff` found an appointment change with no conflicting source *and* no busy-time conflict, this skill writes it to Google Calendar via `gog` immediately, no pause. Confirmed feasible: `gog calendar search` locates any existing event, then `gog calendar create` or `gog calendar update` writes it (upstream command index confirms both exist and request the full read-write calendar scope). Exact flags are still checked live (`gog calendar <subcommand> --help`) since those can shift between versions.
- If sources disagree on that same appointment, or the time double-books against something else on the calendar, it holds and asks for explicit approval instead of guessing.
- Every other action type — sending a WhatsApp message via `wacli send`, editing `care-state.json`, assigning a task, sharing information, deleting a record, rescheduling an appointment through the portal — always waits for explicit approval, no exceptions.
- Output: updated `care-data/care-state.json`, appended `care-data/care-action-audit.jsonl` entries, and a final status report (what ran, what's still blocked or unresolved, who owns it).

## Files passed between stages

All of the following live in `care-data/`.

| File | Written by | Read by | Contains |
| --- | --- | --- | --- |
| `care-connections.json` | care-onboarding | caregiver-inbox, care-source-sync, care-action-executor | which sources are connected and how narrowly scoped |
| `care-state.json` | care-onboarding (seeded empty), care-source-sync (`lastConfirmedCheck` only), care-action-executor (care content) | care-source-sync, care-state-diff | the last confirmed care state |
| `incoming-updates.json` | care-source-sync | care-state-diff | new items since last check, source-tagged |
| `findings.json` | care-state-diff | care-briefing, care-action-executor | classified items, conflicts flagged |
| `caregiver-briefing-<date>.md` | care-briefing | the caregiver (human) | the readable summary |
| `care-action-audit.jsonl` | care-action-executor | (append-only log) | every proposal, approval, execution, or blocked outcome |

## Where it pauses for you

- **Missing/disconnected source** → automatically hands off to `care-onboarding`, scoped to what's missing.
- **Conflicting sources on a calendar item** (including the calendar's own existing entry) → stops, waits for your confirmation before writing.
- **Busy-time conflict on a calendar item** (double-booking) → stops, waits for your confirmation before writing.
- **Anything else external** (message send, care-plan edit, task assignment, sharing info, deletion, appointment reschedule) → always stops and waits for your explicit approval, regardless of conflict status.
- **Everything else** (calendar items with agreeing sources and no busy-time conflict) → proceeds automatically and tells you afterward what it did.

## Known limitations

- **The demo fixtures (`shared/assets/demo/`) use a different fictional patient** ("Mdm Lim Mei Ling") than the one actually seeded in the live `mock-health-portal` backend ("Mr Jia Sijia", `SYNTHETIC-001`). The fixtures illustrate file shape only — they are not meant to be loaded against the live portal.
