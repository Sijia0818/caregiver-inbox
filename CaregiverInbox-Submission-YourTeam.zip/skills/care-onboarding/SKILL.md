---
name: care-onboarding
description: One-time first-run setup for Caregiver Inbox. Installs and scopes the source connections the rest of the pipeline depends on — WhatsApp via wacli, Google Calendar via gog, and the mock-health-portal API — and writes care-connections.json. This must run, and care-connections.json must exist with connected sources, before caregiver-inbox, care-source-sync, or care-action-executor can do anything real. Use when the user is setting up Caregiver Inbox for the first time, or explicitly asks to connect, reconnect, or rescope a source.
agent_created: true
---

# Care Onboarding

## Overview

Get every source the pipeline needs into a known, scoped, verified state, and record that state in `care-data/care-connections.json`. This is a setup skill, not a coordination skill — it does not read care updates or produce a briefing.

## When to Use

- The very first time the user runs Caregiver Inbox and `care-data/care-connections.json` does not exist yet.
- The user explicitly asks to connect, reconnect, or widen/narrow the scope of a source ("connect my calendar", "the WhatsApp sync stopped working", "add the demo chat again", "also read from this number", "only use my other Google account now").

Do not re-run this automatically on every session. Once `care-data/care-connections.json` shows a source as `connected`, later runs trust it until the user says otherwise or `care-source-sync` reports a source has stopped working.

**The scope the agent is allowed to read from — which WhatsApp chat/numbers, which Google account/calendar — is the user's to change at any time, on request, not just during initial setup.** When they ask, this is a fast rescoping, not a full re-run:

- **WhatsApp**: if wacli is already authenticated (`wacli doctor` healthy), skip straight to re-asking the scoping question (Step 2.4 below) — no need to redo `wacli auth`. Update `scope` in `care-data/care-connections.json` to exactly what they now say, and confirm the new scope back to them plainly (what was removed, what was added).
- **Google Calendar**: if they want a *different calendar on the same account*, that's just changing which calendar ID is used (Step 3.7) — no re-auth needed. If they want a *different Google account entirely*, that needs a fresh `gog auth add <new-email> --services calendar` (Step 3.5) — the existing OAuth client from Step 3.3 can be reused, no need to recreate it in Google Cloud Console.

In both cases, treat this as replacing the recorded scope, not adding to it, unless the user explicitly says to add alongside the existing one.

## Required Operating Rules

- Follow `shared/references/safety-and-source-rules.md` in full, especially the Development and Demo Data section.
- Never widen WhatsApp sync beyond one dedicated demo conversation. Do not sync or read the caregiver's real message history.
- All care-plan content connected through these sources for development/demo purposes must be synthetic (fictional patient, fictional family members) even when the transport account (WhatsApp, Google Calendar) is real.
- State plainly which sources succeeded and which did not. Never mark a source `connected` without a tool actually confirming it.

## Step 1 — Check current state

`care-data/` lives at a fixed location — `~/Desktop/care-data/` (`%USERPROFILE%\Desktop\care-data` on Windows) — no search needed to find it, unlike `mock-health-portal/`. If it doesn't exist yet, create it — this is expected on a new machine or for a new user, not an error.

Read `care-data/care-connections.json` if it exists. Only proceed with sources that are missing or the user wants to change. Report existing connections back to the user before touching anything.

## Checking availability the right way

Check by running the skill's own status command (`wacli doctor`, `gog auth list`) and interpreting the result — not `command -v wacli` / `command -v gog`. A `command -v` check only tells you whether a binary is on the host PATH; it can't tell you whether the skill is authenticated, and on some WorkBuddy setups these skills are documentation wrappers around a CLI with no bundled binary, so the two checks can disagree. Running the skill's own status command distinguishes "not installed" from "installed but not authenticated" in one step, which is what actually matters here.

- `wacli doctor` — if it runs and returns health output, wacli is installed. If WorkBuddy reports the skill/command doesn't exist at all, it genuinely isn't installed — direct the user to the WorkBuddy Skills marketplace to install it before continuing.
- `gog auth list` — same idea. A real (even empty) account list means gog is installed; "command not found" means it isn't — direct the user to the WorkBuddy Skills marketplace to install it before continuing, same as wacli.

Only after confirming the skill itself is installed should you move to whether it's *authenticated* (logged in / OAuth'd) versus just *installed but not yet connected* — these are two different failure states and the user needs to know which one they're in.

## Step 2 — Connect WhatsApp via wacli

1. Confirm wacli is installed per the check above.
2. Run `wacli doctor`. If it reports not authenticated, run the one-time login: `wacli auth` — this opens a QR code; the user scans it from WhatsApp on their phone (Linked Devices → Link a Device). This links their real account, so confirm with the user before running it.
3. Re-run `wacli doctor` to confirm health after login.
4. **Critical scoping step — ask, don't assume**: once auth succeeds, explicitly ask the user: *"Which WhatsApp group chat, or which phone number(s), should I be allowed to read messages from?"* Do not proceed until they give a specific answer — never default to "all chats," never pick one for them, never widen it later without asking again. Their answer can be one group chat, one contact's number, or a short list of numbers; record exactly what they said, not your own interpretation of it.
5. Resolve what they named to a concrete identifier: `wacli chats list --limit 20 --query "<group or contact name>"` for a named chat, or resolve directly from a phone number for a 1:1 contact.
6. Confirm going forward, all reads are scoped to exactly what the user specified — that one chat, or only messages involving those specific numbers — e.g. `wacli messages search "<term>" --chat <jid>` or `wacli sync --follow` filtered to that jid/those numbers. Never an unscoped full-history sync, and never silently expand scope later.
7. Sending is only ever done later by `care-action-executor`, after explicit approval, with an explicit recipient and message: `wacli send text --to "<number>" --message "<text>"`.
8. Record in `care-data/care-connections.json`: `sourceId: "whatsapp-demo"`, `tool: "wacli"`, `scope` naming exactly the chat or number(s) the user specified, `status: "connected"`, `verifiedAt` set to now.

**Expected failure mode**: the linked-device session can drop if the phone stays offline too long, and `wacli doctor` will start reporting not-authenticated again even though nothing here changed. That's a re-auth (`wacli auth`), not a re-scoping — don't recreate the demo chat, just log in again.

## Step 3 — Connect Google Calendar via gog

1. Confirm gog is installed per the check above.
2. Run `gog auth list`. If it returns a real account, skip to step 5. If it's empty or reports no account, ask the user whether they already have a Google Cloud OAuth client (Desktop app type) downloaded as a JSON file. If yes, skip to step 4.
3. **If they don't have one yet, walk them through creating it — one screen at a time, waiting for them to confirm each is done before moving to the next.** This happens in their browser; you cannot do it for them.
   1. Go to [console.cloud.google.com](https://console.cloud.google.com) and sign in with the Google account they want the calendar connected to.
   2. Create a new project (or pick an existing one) from the project selector at the top of the page.
   3. Go to **APIs & Services → Library**, search for "Google Calendar API", and click **Enable**.
   4. Go to **APIs & Services → OAuth consent screen**. Choose **External** user type. Fill in the required app name/support email fields — anything reasonable works, this isn't published publicly.
   5. Under **Test users**, add their own Google account email. This is what keeps the app in "Testing" mode — see the failure mode below for what that means.
   6. Go to **APIs & Services → Credentials → Create Credentials → OAuth client ID**. Application type: **Desktop app**. Give it any name.
   7. After creation, click **Download JSON** and note where it saved (e.g. `~/Downloads/client_secret_....json`).
4. Register the client: `gog auth credentials <path-to-downloaded-json>`.
5. Add the account and scope to Calendar only unless the user wants more: `gog auth add <email> --services calendar`. This opens a browser OAuth consent flow — confirm with the user before running it.
6. Re-run `gog auth list` to confirm.
7. Confirm which calendar to use (usually `primary`) by listing upcoming events: `gog calendar events primary --from "<now>" --to "<+7d>"`.
8. `gog calendar create` / `gog calendar update` / `gog calendar search` are confirmed to exist (upstream command index) — `care-action-executor` uses these for writes. Flag-level syntax for each can still shift between versions, so inspect `gog calendar <subcommand> --help` at the time of use rather than assuming exact flags.
9. Record in `care-data/care-connections.json`: `sourceId: "google-calendar"`, `tool: "gog"`, `scope: "primary calendar of <email>"`, `status: "connected"`, `verifiedAt` set to now.

**Expected failure mode**: because the consent screen from step 3.5 stays in "Testing" mode (not published to the public), its refresh token expires after 7 days, and `gog auth list` will suddenly show no valid account a week later. That's a re-auth (`gog auth add` again), not a broken setup. Mention this to the user right when setup finishes, not just when it breaks — ask if they'd rather publish the OAuth consent screen now (**APIs & Services → OAuth consent screen → Publish App**) to avoid the weekly re-auth, since that's a 30-second decision here versus a recurring interruption later.

## Step 4 — Connect the mock health portal

1. Check `mock-health-portal` is reachable: request `http://127.0.0.1:8000/api/health`.
   - If it responds, it's already running — do not start a second instance. Move on.
   - If it fails to connect (not just an error response — an actual connection failure), the backend process is not running. Start it directly, without asking the user to do it manually. Locate `mock-health-portal/` via the bounded search procedure in `shared/references/care-connections-schema.md` — never an unbounded filesystem scan, never a hardcoded path. Then run, from the discovered `mock-health-portal/backend` directory:
     ```bash
     source .venv/bin/activate && uvicorn app.main:app --host 127.0.0.1 --port 8000 &
     ```
     (Run `python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt` first if `.venv` doesn't exist yet.) Then retry the health check.
   - Do not proceed to the next step until the health check responds.
2. Check whether any installed skill can make a direct HTTP call to that local address (WorkBuddy itself, if it supports issuing an HTTP request directly, or another installed skill with that capability). If confirmed, record `tool: "direct_http"`.
3. If no installed skill can reach it, record `status: "not_connected"`, `tool: "unavailable"`, and a note explaining what was tried. Do not claim this source works.
4. Pin `sourceId: "care-portal"` and `displayName: "Mock HealthHub (CarePortal Sandbox)"` for this entry — `care-source-sync` and `care-action-executor` key off the exact `sourceId` string, so neither field should vary between runs.
5. Map operations against `mock-health-portal/docs/connector-contract.md`, located by searching the filesystem for the `mock-health-portal` directory (the same search used in Step 4.1 above) — never assume a relative path. Do not depend on the portal's SQLite schema directly.

## Step 5 — Final verification pass

Do not trust the setup steps above just because they were followed — re-run the actual status check for every source, right now, and use only what comes back:

- `care-portal`: request the health endpoint again.
- `whatsapp-demo`: `wacli doctor`.
- `google-calendar`: `gog auth list`.

Build a plain results table (source, check run, result) before writing anything. Any source that isn't confirmed by this pass is `not_connected`, regardless of what an earlier step assumed.

## Step 6 — Write and report

Write the full `care-data/care-connections.json` using only the Step 5 results.

If `care-data/care-state.json` does not exist yet, initialize it now using the empty shape in `shared/references/care-state-schema.md` (all record arrays empty, no `lastConfirmedCheck`) so the first `care-source-sync` run retrieves everything from scratch. Do not seed it from `shared/assets/demo/confirmed-care-state.json` — that fixture's persona ("Mdm Lim Mei Ling") is illustrative only and does not match whatever patient the connected `mock-health-portal` actually returns; seeding from it would plant the wrong subject identity. Let the first real sync populate `subject` from the portal's own response instead.

Then tell the user, plainly and per source:

- What is connected and its exact scope, confirmed by the Step 5 check.
- What is not connected, and which of two states it's in: not installed (needs the WorkBuddy Skills marketplace) vs. installed but not authenticated (needs the specific auth command above).
- The exact next command to run for anything not yet connected.
- What they still need to do manually, if anything, before `caregiver-inbox` can run a full pipeline.
- That the visual CarePortal Sandbox UI is available but not started automatically, since nothing in the pipeline needs it — only mention how, don't start it: `cd mock-health-portal/frontend && npm install && npm run dev`, then open `http://localhost:5173`.
