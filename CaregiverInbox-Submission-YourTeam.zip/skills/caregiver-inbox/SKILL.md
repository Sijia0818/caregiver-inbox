---
name: caregiver-inbox
description: Entry point for care coordination for family caregivers supporting an older adult at home. Checks that sources are connected, then runs the full pipeline — retrieve new updates, compare against the confirmed care plan, produce a caregiver briefing, and execute approved actions — without giving medical advice. Use for requests such as "check Mum's new updates," "prepare today's caregiver briefing," "what needs attention," or "coordinate Mum's appointment."
agent_created: true
---

# Caregiver Inbox

## Overview

This is the skill the caregiver actually talks to. It does not retrieve, classify, or execute anything itself — it checks preconditions and explicitly sequences the specialized skills that do:

`care-onboarding` (once) → `care-source-sync` → `care-state-diff` → `care-briefing` → pause for approval → `care-action-executor` → close the loop.

## Required Operating Rules

- Follow `shared/references/safety-and-source-rules.md` at every step.
- Never skip straight to execution. The briefing must be shown before `care-action-executor` runs, except for the calendar auto-write exception documented in that skill.
- Once "full pipeline" is chosen in Step 3, run sync → diff → briefing straight through without pausing to ask "should I continue?" between them — choosing "full pipeline" already answered that. The only intended pauses are the briefing hand-off before execution, and the individual approval gates inside `care-action-executor`. Do not invent additional checkpoints.
- Keep informal home-care coordination administrative only — never diagnose, prescribe, or resolve medical contradictions independently.

## Step 1 — Check connections

`care-data/` lives at a fixed location — `~/Desktop/care-data/` (`%USERPROFILE%\Desktop\care-data` on Windows) — no search needed.

Read `care-data/care-connections.json`. If it does not exist, or a source the user is asking about is `not_connected`, do not attempt a partial pipeline against an unverified source — automatically hand off to `care-onboarding`, scoped to just the missing/unconnected source(s), so the user is walked straight into setup instead of being told to run a separate command themselves. This hand-off is automatic; the account-linking actions inside `care-onboarding` (QR scan, OAuth consent) are not and never will be — those still require the user's explicit, in-the-moment confirmation. Resume this run afterward if onboarding completes successfully; if the user can't or doesn't complete it, report plainly what's still missing and stop.

`care-portal` is a local process and can die between sessions (laptop restart, closed terminal) even after `care-onboarding` recorded it as `connected` — a cached status is not proof it's up right now. Before trusting it for this run:

1. Probe it live: request `http://127.0.0.1:8000/api/health`.
   - Responds → already running, proceed as-is, do not restart it.
   - Fails to connect → not running right now. Start it directly, without asking the user to do it manually, from the already-discovered `mock-health-portal/backend` directory: `source .venv/bin/activate && uvicorn app.main:app --host 127.0.0.1 --port 8000 &` (run `python3 -m venv .venv && source .venv/bin/activate && pip install -r requirements.txt` first if `.venv` doesn't exist — it normally will from `care-onboarding`, but don't assume it survived). Re-probe before proceeding.
2. Only fall back to automatically handing off to `care-onboarding` if the portal still can't be reached after attempting to start it — not on the first failed probe.

## Step 2 — Establish scope for this run

- Identify the older adult or synthetic subject.
- Confirm which of the connected sources are authorized for this run.
- Limit retrieval to the narrowest relevant time window and source set.

## Step 3 — Decide pipeline scope

Ask (or infer from the request) whether this run should be:

- **Full pipeline**: sync → diff → briefing → approval → execute → close the loop.
- **Partial**: e.g. "just show me the briefing from what we already have" (skip sync), or "just check for new updates" (stop after sync/diff).

## Step 4 — Run in sequence

Invoke each skill in order for the scope decided in Step 3, back to back, without stopping between them to ask for confirmation. Pass each skill's output file (`care-data/incoming-updates.json`, `care-data/findings.json`, `care-data/caregiver-briefing-<date>.md`, `care-data/care-action-audit.jsonl`) forward as-is — do not re-derive or summarize between steps in a way that drops source/timestamp/evidence detail.

If the user interjects mid-run with a real-time update ("I just sent a message, check again," "I just added something") for a source that's already been synced this run, treat it as an explicit request to re-run `care-source-sync` for that specific source before continuing — never silently proceed on the data already gathered, and never silently absorb the request without confirming back what the fresh check actually found (including "checked again, still nothing new" if that's the honest answer).

## Step 5 — Close the loop

At the end of the run, state plainly:

- What was successfully updated (including anything `care-action-executor` auto-wrote to the calendar because sources agreed and there was no busy-time conflict)
- What remains unresolved, including any possible contradictions still awaiting the caregiver's confirmation
- Who owns each outstanding item
- What should be checked next time
