---
name: care-source-sync
description: Retrieve only new or changed care-relevant information since the last confirmed check, from every source recorded as connected in care-connections.json (the mock-health-portal API, WhatsApp via wacli scoped to the dedicated demo conversation). Normalize everything into a common source-linked format. Use when caregiver-inbox needs fresh updates, or the user asks to check for new updates, refresh sources, or pull the latest from Mum's portal or messages.
agent_created: true
---

# Care Source Sync

## Overview

Pull the smallest relevant set of new information from every connected, scoped source, tag it with provenance, and hand it off in a common shape. This skill does not compare against the confirmed care state and does not classify conflicts — that is `care-state-diff`'s job. This skill only answers: what is new since last time, and where did it come from.

## Preconditions

- `care-data/` lives at a fixed location — `~/Desktop/care-data/` (`%USERPROFILE%\Desktop\care-data` on Windows) — no search needed. If invoked directly rather than via `caregiver-inbox`, this resolution still applies.
- Read `shared/references/care-connections-schema.md` and the current `care-data/care-connections.json`.
- For any source with `status: not_connected`, skip it and say so plainly in the run summary. Never silently treat a missing source as "no updates."
- If `care-data/care-connections.json` does not exist at all, automatically hand off to `care-onboarding` rather than stopping with an instruction to run it separately — same pattern as `caregiver-inbox` Step 1. If it exists but a specific source the user explicitly asked about is `not_connected`, hand off to `care-onboarding` scoped to that source; if the source just wasn't part of what was asked for, the existing skip-and-report behavior below is enough — that's an intentional partial setup, not something to interrupt for.

## Step 1 — Determine the retrieval window

Read `lastConfirmedCheck` from `care-data/care-state.json`. Only retrieve items newer than that timestamp from each source. If `lastConfirmedCheck` is absent (a fresh `care-state.json`, e.g. immediately after `care-onboarding` seeded it empty), treat this run as the baseline: retrieve everything available from each connected source rather than erroring or guessing a window.

## Step 2 — Retrieve from the mock health portal

Using whichever `tool` `care-data/care-connections.json` records for `sourceId: "care-portal"` (currently `direct_http`), call the connector operations defined in `mock-health-portal/docs/connector-contract.md`, located via the bounded search procedure in `shared/references/care-connections-schema.md` (the same one used to find the backend) — never assume a relative path:

- `get_recent_updates` with `since=<lastConfirmedCheck>`
- `get_appointments` / `get_appointment_details` for any appointment referenced by an update
- `get_health_documents`, `get_outstanding_actions` as relevant

Preserve, for every item: source system identifier, subject/patient ID, retrieval timestamp, stable resource ID, source timestamp, and the raw text/data exactly as returned. Do not interpret medical content — pass it through.

## Step 3 — Retrieve from WhatsApp via wacli

- Confirm the scope recorded in `care-data/care-connections.json` names the exact chat or number(s) the user specified during onboarding. If it's missing or unclear, stop and say so — do not read any chat or number beyond what's explicitly recorded there.
- Pull new messages since the last check, scoped to that one chat. `wacli messages search` takes a positional query term (e.g. `wacli messages search "*" --chat <jid> --limit 50`) — inspect `wacli messages --help` to confirm the exact syntax for an unfiltered/all-messages read rather than assuming a query-less form works. A filtered `wacli sync --follow` read restricted to that jid is the alternative if search requires a non-empty query.
- Never call `wacli chats list` beyond confirming the one scoped jid already on file, and never read or reference any other conversation.

## Step 4 — Retrieve from Google Calendar

Skip this step entirely if `google-calendar` is `not_connected` in `care-data/care-connections.json` — portal appointments then get no calendar comparison or busy-time check, and `care-state-diff` should not expect one.

For each appointment retrieved from the portal in Step 2:

- Use `gog calendar search` to check whether an event already exists for it on the connected calendar (`care-data/care-connections.json` → `google-calendar`).
- If found and its date/time/location differs from what the portal (or any other source) reports, produce an item for it — this is a real signal, most often that someone edited the calendar directly outside the pipeline, or the calendar is stale from before a portal change.
- Also run `gog calendar conflicts` for the appointment's proposed time slot to check whether it overlaps another existing calendar commitment (a busy-time double-booking). If it does, produce an item flagging this — it's not a source disagreement, it's a scheduling clash, but `care-state-diff` and `care-action-executor` both need to know about it before any auto-write.

This is the one case where this skill reads from a source it also writes to elsewhere in the pipeline — that's fine; the read here is only ever used for comparison, never treated as authoritative on its own.

## Step 5 — Filter to care-relevant content

From the raw retrieval, keep only items that map to one of the categories in `shared/references/care-state-schema.md`: appointments, preparation requirements, care instructions, task changes, completed tasks, caregiver availability, equipment or supply issues, administrative items, unanswered questions, plus the calendar-mismatch and busy-time-conflict items from Step 4. Discard unrelated chatter and low-value content without recording it.

## Step 6 — Normalize

For each kept item, produce a record shaped like the existing fixture at `shared/assets/demo/incoming-updates.json`:

```json
{
  "id": "stable-id",
  "type": "appointment_update | family_message | equipment_observation | ...",
  "description": "concise plain-language summary",
  "source": {
    "type": "healthcare_api | messaging_connector",
    "name": "Mock HealthHub | WhatsApp (simulated)",
    "reference": "resource id or message id",
    "rank": 1
  },
  "sourceTimestamp": "ISO timestamp from the source",
  "evidenceQuote": "short quoted or extracted evidence",
  "uncertainty": "what is unknown or unverified"
}
```

Use source rank per `shared/references/safety-and-source-rules.md`: portal API = 1, appointment letter/document = 2, appointment SMS/email = 3, caregiver-entered record = 4 (a calendar entry not written by this pipeline counts as caregiver-entered — rank 4), family/helper message (including WhatsApp) = 5. A busy-time-conflict item from Step 4 has no source rank — it isn't a disagreement between sources, tag it `type: "calendar_busy_conflict"` instead and let `care-state-diff` handle it separately from ranked contradictions.

Do not set a `classification` field here — that belongs to `care-state-diff`.

## Step 7 — Write output and report

Write the normalized batch to `care-data/incoming-updates.json`. After a successful write, also advance `care-data/care-state.json`'s `lastConfirmedCheck` to this run's retrieval timestamp — this is the one field in that file `care-source-sync` is allowed to write. Every other field (appointments, tasks, and the rest of the confirmed care content) remains `care-action-executor`'s exclusive responsibility, updated only after approval. Advance it even on a partial run that stops after sync — the window should reflect what's actually been checked, independent of whether anything found gets acted on.

Tell the user which sources were checked, which were skipped and why, and how many new items were found per source.
