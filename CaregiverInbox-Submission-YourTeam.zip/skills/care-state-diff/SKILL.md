---
name: care-state-diff
description: Compare newly retrieved updates against the confirmed local care state, classify each item, apply source-ranking when sources disagree, and detect which calendar, task, or family arrangements are affected. Use after care-source-sync has produced incoming-updates.json, or when the user asks to compare updates against the care plan or check for conflicts.
agent_created: true
---

# Care State Diff

## Overview

Turn raw, source-tagged updates into a classified set of findings the caregiver can act on. This skill does not retrieve data and does not execute actions — it only compares and classifies.

## Inputs

`care-data/` lives at a fixed location — `~/Desktop/care-data/` (`%USERPROFILE%\Desktop\care-data` on Windows) — no search needed. This applies whether invoked via `caregiver-inbox` or directly by the user.

- `care-data/incoming-updates.json` (from `care-source-sync`)
- `care-data/care-state.json` (the confirmed local state — never long-term memory)

## Step 1 — Classify each item

For each item in `care-data/incoming-updates.json`, classify against `care-data/care-state.json` as one of:

- New information
- Changed information
- Completed action
- Unresolved question
- Possible contradiction
- Duplicate or already handled
- Informational only

Prioritize differences; do not restate the entire care plan when only a few items changed.

## Step 2 — Resolve conflicts safely

When two or more sources disagree on the same fact (most commonly an appointment date, time, or location):

- Classify as "Possible contradiction."
- Show every conflicting value with its source, timestamp, confirmation status, and evidence.
- Use the source ranking in `shared/references/safety-and-source-rules.md` to guide which value to prioritize for review — never to delete or hide the lower-ranked evidence.
- Never resolve the contradiction automatically. Leave it for the caregiver (via `care-action-executor`) to confirm.

When only one source has reported a fact and no other checked source contradicts it, this is not a contradiction — classify it as "New information" or "Changed information" as appropriate, and note which sources were actually checked.

Google Calendar counts as a ranked source here (rank 4, per `care-source-sync`) when it has an existing entry for an appointment — if what's on the calendar disagrees with the portal or any other source, that's a "Possible contradiction" like any other, not something to overwrite silently.

## Step 3 — Flag busy-time conflicts

A `calendar_busy_conflict` item (from `care-source-sync` Step 4) is not a source disagreement — it means a proposed appointment time overlaps an existing calendar commitment. Do not classify it under Step 2's contradiction handling. Instead, mark the corresponding appointment finding as having a busy-time conflict, separate from (and in addition to) whether its sources agree. Both dimensions matter to `care-action-executor`'s auto-write decision.

## Step 4 — Detect administrative consequences

For each meaningful (non-duplicate, non-informational) item, check whether it affects:

- Calendar events
- Caregiver availability
- Transport
- Documents or lists to prepare
- Family assignments
- Senior activities
- Equipment arrangements
- Follow-up messages
- Existing tasks and deadlines

Do not infer clinical consequences. Never judge whether a symptom, medication issue, or equipment issue is safe — flag it as requiring inspection or professional clarification per `shared/references/safety-and-source-rules.md`.

## Step 5 — Write findings

Write `care-data/findings.json`, one record per meaningful item, using the field envelope in `shared/references/care-state-schema.md` (`id`, `category`, `description`, `source`, `sourceTimestamp`, `confirmationStatus`, `assignedPerson`, `actionStatus`, `relatedRecordIds`, `evidenceQuote`, `notes`, `uncertainty`). Set `actionStatus` to `proposed` for anything that will need `care-action-executor` to act on it. For appointment items, note both conditions `care-action-executor` needs for its auto-write decision (see the Calendar Update Exception in the safety rules): whether the item is free of source contradictions (Step 2), and whether it's free of busy-time conflicts (Step 3). Both must hold for an auto-write; either one failing means it waits for approval.

## Step 6 — Report

Summarize what changed, grouped by classification, before handing off to `care-briefing`.
