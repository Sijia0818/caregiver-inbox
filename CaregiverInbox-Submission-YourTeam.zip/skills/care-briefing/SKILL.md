---
name: care-briefing
description: Turn classified findings into a concise caregiver briefing using the standard template. Use after care-state-diff has produced findings.json, or when the user asks for today's caregiver briefing or a summary of what needs attention.
agent_created: true
---

# Care Briefing

## Overview

Render `care-data/findings.json` into a short, human-readable briefing. This skill does not retrieve or classify data, and does not execute or send anything — it only reports.

## Input

`care-data/findings.json` (from `care-state-diff`)

## Step 1 — Select and group

Group findings into the template's sections:

- Needs attention now
- Completed
- Waiting for others
- Possible conflicts
- Informational updates

Keep it concise — prioritize what changed over restating the full care plan.

## Step 2 — Fill in required detail per action-oriented item

For every item in "Needs attention now" and "Possible conflicts," include:

- What changed
- Why it matters administratively (never clinically)
- Source and timestamp
- Current status
- Recommended next action
- Whether approval or professional clarification is required

## Step 3 — Render

Use `shared/assets/caregiver-briefing-template.md` exactly. Fill the "Draft actions for approval" section with anything `care-action-executor` will need to present for sign-off — do not send or execute anything here, only draft and label clearly as a draft.

## Step 4 — Output

`care-data/` lives at a fixed location — `~/Desktop/care-data/` (`%USERPROFILE%\Desktop\care-data` on Windows) — no search needed — this applies whether invoked via `caregiver-inbox` or directly by the user. Save as `care-data/caregiver-briefing-<date>.md` and show it to the user. This briefing is the handoff point to `care-action-executor` — nothing proceeds to execution until the user has seen this and responds.
