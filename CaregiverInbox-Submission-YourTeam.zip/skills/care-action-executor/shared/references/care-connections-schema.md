# Care Connections Schema

## Where the runtime data lives

All runtime data — `care-connections.json`, `care-state.json`, `incoming-updates.json`, `findings.json`, `caregiver-briefing-<date>.md`, `care-action-audit.jsonl` — lives in a `care-data/` folder at a **fixed** location: `~/Desktop/care-data/` (`%USERPROFILE%\Desktop\care-data` on Windows). No search needed to find it — every skill can just use this path directly, and `care-onboarding` creates it on first run if it doesn't exist.

It is real per-user runtime state — synthetic care content, but potentially a real linked account's data — so it is never committed to the repo (`.gitignore`'d), and never included when packaging the project for another user; they get an empty slate and `care-onboarding` creates their own on their own Desktop.

## Locating mock-health-portal/

This is a separate concern from `care-data/` above — `mock-health-portal/` is the actual project folder (backend + frontend), and unlike `care-data/` its location genuinely varies (wherever the person keeps their projects), so it does need a search. Every skill that calls the portal API or needs to start its backend locates it this way.

### Bounded search procedure

Never run an unbounded scan of the entire filesystem or drive to find `mock-health-portal/`. On macOS this walks into TCC-protected locations (Photos, Music library, iCloud Drive, etc.) and triggers a permission prompt for each one it touches, even though none of them are relevant. On Windows it can wander into slow network/OneDrive-synced paths or restricted system folders for the same reason: nothing bounds where a full scan looks. Both are avoidable — the project's location is never arbitrary, it's wherever the person keeps their own projects.

Search in this order, stopping at the first match (a directory named `mock-health-portal` containing `backend/app/main.py`):

1. The current working directory, and a few levels of its parent directories.
2. Common project locations, one level deep (not recursive into everything inside them): `~/Desktop`, `~/Documents`, `~/Projects` on macOS/Linux; `%USERPROFILE%\Desktop`, `%USERPROFILE%\Documents` on Windows.
3. If still not found, ask the user directly for the project's path rather than continuing to search broadly. A missed match is a two-second question, not a reason to scan everything.

## Purpose

`care-connections.json` is the single source of truth for which upstream sources are actually connected, scoped, and safe to use. Every other skill must read it before claiming access to a source — never assume a connector works because it worked in a previous run.

## Shape

```json
{
  "lastCheckedAt": "2026-08-09T09:00:00+08:00",
  "sources": [
    {
      "sourceId": "care-portal",
      "displayName": "Mock HealthHub (CarePortal Sandbox)",
      "type": "healthcare_api",
      "tool": "direct_http",
      "scope": "patient SYNTHETIC-001 only",
      "status": "connected",
      "verifiedAt": "2026-08-09T09:00:00+08:00",
      "notes": ""
    },
    {
      "sourceId": "whatsapp-demo",
      "displayName": "WhatsApp (simulated)",
      "type": "messaging_connector",
      "tool": "wacli",
      "scope": "single dedicated demo conversation only",
      "status": "connected",
      "verifiedAt": "2026-08-09T09:00:00+08:00",
      "notes": "jid recorded here; never widen scope beyond this chat"
    },
    {
      "sourceId": "google-calendar",
      "displayName": "Google Calendar",
      "type": "calendar_connector",
      "tool": "gog",
      "scope": "primary calendar of the connected account",
      "status": "not_connected",
      "verifiedAt": null,
      "notes": ""
    }
  ]
}
```

## Field Notes

| Field | Meaning |
| --- | --- |
| `sourceId` | Stable key other skills reference |
| `tool` | The actual installed skill/connector used: `wacli`, `gog`, `direct_http`, or `unavailable` |
| `scope` | Plain-language description of what this source is allowed to touch. For WhatsApp this must always name a single dedicated conversation, never "all chats" or "full history" |
| `status` | `connected` or `not_connected` — never inferred, only set after `care-onboarding` actually verifies it |
| `verifiedAt` | When the connection was last actually checked, not when it was first set up |

## Rules

- A source with `status: not_connected` must be treated as unavailable. Say so plainly; do not retry silently or substitute another source without asking.
- Widening a `scope` (e.g. syncing more WhatsApp chats) requires re-running `care-onboarding`, not a silent edit to this file.
- This file itself contains no care content — only connection metadata. Keep it separate from `care-state.json`.
