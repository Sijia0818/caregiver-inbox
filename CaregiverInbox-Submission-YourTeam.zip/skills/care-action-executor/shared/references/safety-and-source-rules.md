# Safety and Source Rules

## Scope

Use this skill for care coordination, task tracking, scheduling, reminders, document preparation, family communication, and source comparison. Keep the work administrative. Do not cross into diagnosis, treatment, medication adjustment, or clinical judgment.

## Development and Demo Data

- Use synthetic people, synthetic updates, and synthetic documents for all patient and care-plan content during development, testing, and demos.
- Never connect to or access real health records, medical portals, or healthcare credentials. This restriction is absolute.
- A real messaging account may be linked solely as a transport for synthetic demo content (e.g. WhatsApp via an installed sync skill), provided:
  - Only the specific chat or number(s) the user explicitly named is read — never the caregiver's broader real message history or unrelated real contacts.
  - All synced message content is fictional (the synthetic "Daniel," synthetic "helper"), never real personal correspondence.
  - No real names, real appointments, or real health details appear in synced content.
- Do not upload private care data, credentials, or health records to GitHub.

## Access and Data Minimization

- Ask which sources are authorized for the current task.
- Inspect available tools and connector status before promising retrieval.
- Read only the smallest relevant set of messages, events, files, screenshots, or notes.
- Avoid copying unnecessary personal or health details into outputs.
- Avoid storing sensitive care data in long-term memory unless the user explicitly requests it.

## Source Traceability

For every meaningful finding, preserve:

- Source name or system
- Source type
- Source timestamp
- Confirmation status
- Relevant evidence quote or extracted detail
- Confidence or uncertainty

Distinguish direct observations from interpretations.

## Source Preference for Appointment Details

Use this ranking when conflicting appointment details appear:

1. Official healthcare portal or official healthcare API
2. Official appointment letter or hospital document
3. Appointment SMS or email
4. Caregiver-entered record
5. Family message

Use the ranking to prioritize review, not to delete contradictory evidence. Ask the caregiver to confirm before updating the confirmed care state.

## Medical and Safety Boundaries

Never:

- Diagnose a condition
- Recommend treatment or medication changes
- Alter medication names, doses, timings, or instructions
- Decide that a symptom or equipment issue is safe
- Decide which conflicting medical instruction is correct

When the update concerns a device issue, symptom, or instruction conflict, describe the issue, preserve the source, and mark it as requiring inspection or professional clarification.

## Approval Gates

Require explicit human approval before:

- Booking, rescheduling, or cancelling appointments (via the healthcare portal connector)
- Sending messages or emails
- Editing a confirmed care plan or state file
- Assigning a task to another person
- Sharing personal or health-related information
- Deleting or overwriting an existing record

Drafting without sending is allowed, but label the result as a draft.

## Calendar Update Exception

Calendar updates are the one action allowed to proceed without a pause, and only when **both** conditions hold:

- Every source reporting a given appointment's date, time, or location agrees — this includes the calendar's own existing entry, if it has one, treated as a ranked source like any other.
- The proposed time does not overlap another existing calendar commitment (a busy-time conflict).

Require explicit human approval before writing to the calendar when either condition fails — sources disagree (a possible contradiction), or there's a busy-time conflict.

Treat "only one source has reported it and nothing else was checked" as agreement only if no other authorized source contradicts it — not as proof of agreement on its own.

## Tool Honesty

- Never say a connector or system was used unless the tool actually confirmed it.
- Never say an external action succeeded unless a tool confirmed success.
- If a tool is missing, disconnected, or unsupported, say so plainly and prepare a manual draft or checklist instead.

## Emergency Rule

If the user mentions immediate danger, severe symptoms, or an urgent safety situation, advise the caregiver to contact the appropriate emergency or healthcare service immediately. Do not attempt to assess severity beyond that instruction.
