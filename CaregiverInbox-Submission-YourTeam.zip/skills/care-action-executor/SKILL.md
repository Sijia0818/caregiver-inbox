---
name: care-action-executor
description: Present proposed actions from a caregiver briefing for approval, then execute what is approved (or auto-eligible) — write conflict-free appointment changes to Google Calendar via gog automatically, hold conflicting ones for approval, update care-state.json, draft or send WhatsApp messages via wacli only after approval, create tasks. Appends every outcome to care-action-audit.jsonl and tracks status to completion. Use after a briefing has been shown to the caregiver, or when the user says to update the plan, send a draft, or mark something done.
agent_created: true
---

# Care Action Executor

## Overview

Turn approved (or auto-eligible) findings into real changes, honestly. Never claim an action succeeded unless a tool confirmed it. This is the only skill that writes care content to `care-data/care-state.json` (appointments, tasks, assignments, and the rest), and the only skill that calls `gog` or `wacli send`. `care-source-sync` separately advances just the `lastConfirmedCheck` field after a successful retrieval — that's bookkeeping, not care content, and doesn't overlap with this skill's writes.

`care-data/` lives at a fixed location — `~/Desktop/care-data/` (`%USERPROFILE%\Desktop\care-data` on Windows) — no search needed — this applies whether invoked via `caregiver-inbox` or directly by the user.

Before calling `gog` or `wacli send` for a specific action, check `care-data/care-connections.json` for that source's status. If it's `not_connected`, do not attempt the call and fail confusingly — automatically hand off to `care-onboarding` scoped to that source instead. If `care-data/care-connections.json` doesn't exist at all, hand off to `care-onboarding` entirely before proceeding.

## Required Operating Rules

Follow `shared/references/safety-and-source-rules.md` in full. In particular:

### Approval gates (always required)

Require explicit human approval before:

- Booking, rescheduling, or cancelling appointments via the healthcare portal connector
- Sending a WhatsApp message or email
- Editing the confirmed care plan or state file (beyond recording action status)
- Assigning a task to another person
- Sharing personal or health-related information
- Deleting or overwriting an existing record

### Calendar update exception

Google Calendar is the one action allowed to proceed without a pause, and only when **both** conditions hold on the finding:

- `care-state-diff` classified the appointment item as free of source contradictions — every source that reported its date/time/location agrees, including the calendar's own existing entry if it had one.
- `care-state-diff` also marked it free of busy-time conflicts — the proposed time doesn't overlap another existing calendar commitment.

If either condition fails — "Possible contradiction," or a busy-time conflict — it must wait for explicit approval like everything else. Never auto-write a conflicting or double-booked date.

## Step 1 — Partition findings

From `care-data/findings.json`, split into:

- Calendar-eligible for auto-write (appointment changes, free of both source contradictions and busy-time conflicts)
- Everything else (requires approval regardless of type)

## Step 2 — Auto-write conflict-free calendar changes

For each calendar-eligible finding:

1. Use `gog calendar search` on the connected calendar (`care-data/care-connections.json` → `google-calendar`) to check whether an event for this appointment already exists.
2. Found → `gog calendar update`. Not found → `gog calendar create`. Inspect `gog calendar <subcommand> --help` first if flag syntax is unconfirmed for this gog version — the subcommands themselves are confirmed to exist, but exact flags can shift between versions.
3. Record the outcome — event ID, previous value if updated, new value, tool-confirmed success or failure — as an `action` record in `care-data/care-state.json` and append to `care-data/care-action-audit.jsonl`.
4. Tell the user what was auto-updated and why it qualified (sources agreed, no busy-time conflict).

## Step 3 — Present everything else for approval

For each remaining finding, show:

- The proposed action
- The supporting source(s), including both sides of any conflict
- The system or file to be modified
- The person to be contacted, if any

Wait for explicit approval per item (or a batch approval the user clearly gives). Do not proceed on silence or assumption.

## Step 4 — Execute approved actions

Depending on what was approved:

- Update `care-data/care-state.json`
- Update or create a Google Calendar event via `gog` (for conflicting appointments the user has now resolved)
- Draft or send a WhatsApp message via `wacli send text --to "<number>" --message "<text>"` — only with an explicit recipient and message text the user has seen, never a silent send
- Create an appointment-preparation checklist or task
- Generate a handover document

If a required tool is unavailable or fails, say so plainly and produce a reviewable draft or structured action item instead of pretending it succeeded.

## Step 5 — Audit and status

Append one JSON object per action proposal, approval, execution result, or blocked outcome to `care-data/care-action-audit.jsonl`, per the shape in `shared/references/care-state-schema.md`. Track each item's status through: Proposed → Awaiting approval → Approved → Assigned → Acknowledged → Completed → Blocked → Requires professional clarification.

## Step 6 — Close the loop

End the run by stating:

- What was auto-updated (and why it qualified)
- What was approved and executed
- What remains unresolved or blocked, and who owns it
- What should be checked next time
